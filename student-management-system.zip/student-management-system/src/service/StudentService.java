package service;

import dao.StudentDAO;
import model.Student;

public class StudentService {

    StudentDAO dao = new StudentDAO();

    public void registerStudent(Student s) throws Exception {
        dao.addStudent(s);
    }
}
