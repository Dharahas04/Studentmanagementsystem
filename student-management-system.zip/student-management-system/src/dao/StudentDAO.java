package dao;

import util.DBConnection;
import model.Student;
import java.sql.*;

public class StudentDAO {

    public void addStudent(Student s) throws Exception {

        Connection con = DBConnection.getConnection();

        String sql = "INSERT INTO students(first_name,last_name,email) VALUES(?,?,?)";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, s.getFirstName());
        ps.setString(2, s.getLastName());
        ps.setString(3, s.getEmail());

        ps.executeUpdate();

        con.close();
    }
}
