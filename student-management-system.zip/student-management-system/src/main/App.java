package main;

import model.Student;
import service.StudentService;

public class App {

    public static void main(String[] args) throws Exception {

        Student s = new Student();
        s.setFirstName("Sai");
        s.setLastName("Dharahas");
        s.setEmail("sai@gmail.com");

        StudentService service = new StudentService();
        service.registerStudent(s);

        System.out.println("Student inserted successfully!");
    }
}
